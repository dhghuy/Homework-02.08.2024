import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  constructor() { }

  products = [
    {
      id: 1,
      name: "Product 1",
      description: "Best Seller",
      price: 10000,
      inStock: 10
    },

    {
      id: 2,
      name: "Product 2",
      description: "Best Seller",
      price: 15000,
      inStock: 15
    },

    {
      id: 3,
      name: "Product 3",
      description: "Best Seller",
      price: 18000,
      inStock: 5
    }
  ]

  cart: any[] = [];

  addToCart(item: any) {
    if (this.products[item.id - 1].inStock == 0) {
      return;
    }

    let index = this.cart.findIndex((element) => element.id == item.id);
    this.products[item.id - 1].inStock--;
    if (index != -1) {
      this.cart[index].quantity++;
    } else {
      this.cart.push(item);
    }
  }

  removeItem(index: number) {
    this.cart.splice(index, 1);
  }

  
}
